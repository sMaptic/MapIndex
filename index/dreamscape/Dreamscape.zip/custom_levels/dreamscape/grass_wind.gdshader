
shader_type spatial;

render_mode cull_disabled, depth_draw_opaque;

uniform vec2 wind_direction = vec2(1.0, 0.0);
uniform float wind_strength = 0.18;
uniform float wind_speed = 1.5;

void vertex() {
    // Phase différente pour chaque touffe
    float phase = INSTANCE_CUSTOM.r * 6.28318;

    // Variation lente de l'intensité des rafales
    float gust = 0.7 + 0.3 * sin(
        TIME * 0.55 + INSTANCE_CUSTOM.b * 6.28318
    );

    // Mouvement principal
    float sway = sin(
        TIME * wind_speed + phase
    );

    sway *= wind_strength;
    sway *= INSTANCE_CUSTOM.g;
    sway *= gust;

    // La base reste immobile, la pointe bouge davantage
    VERTEX.xz += wind_direction * sway * UV.y;
}

void fragment() {
    ALBEDO = COLOR.rgb;
    ROUGHNESS = 1.0;
}

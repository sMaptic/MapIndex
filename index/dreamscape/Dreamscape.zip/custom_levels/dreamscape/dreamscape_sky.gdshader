
shader_type sky;

uniform vec3 sky_top : source_color = vec3(0.28, 0.65, 0.95);
uniform vec3 sky_horizon : source_color = vec3(0.75, 0.88, 0.98);
uniform vec3 cloud_color : source_color = vec3(1.0, 1.0, 1.0);

uniform float cloud_scale = 3.0;
uniform float cloud_speed = 0.012;
uniform float cloud_coverage = 0.48;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);

    f = f * f * (3.0 - 2.0 * f);

    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));

    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;

    for (int i = 0; i < 4; i++) {
        value += noise(p) * amplitude;
        p *= 2.0;
        amplitude *= 0.5;
    }

    return value;
}

void sky() {
    vec3 dir = normalize(EYEDIR);

    float horizon = smoothstep(-0.15, 0.75, dir.y);
    vec3 base_color = mix(sky_horizon, sky_top, horizon);

    // Nuages uniquement au-dessus de l'horizon
    if (dir.y > 0.015) {
        vec2 uv = dir.xz / max(dir.y, 0.12);

        uv *= cloud_scale;

        // Déplacement continu des nuages
        uv.x += TIME * cloud_speed;

        float clouds = fbm(uv);

        float cloud_mask = smoothstep(
            cloud_coverage,
            cloud_coverage + 0.16,
            clouds
        );

        // Disparition progressive près de l'horizon
        cloud_mask *= smoothstep(0.015, 0.20, dir.y);

        base_color = mix(
            base_color,
            cloud_color,
            cloud_mask
        );
    }

    COLOR = base_color;
}
